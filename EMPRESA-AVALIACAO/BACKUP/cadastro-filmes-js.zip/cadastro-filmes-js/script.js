let filmes = [];


const formFilme = document.getElementById("formFilme");

const tituloInput = document.getElementById("titulo");
const sinopseInput = document.getElementById("sinopse");
const anoInput = document.getElementById("ano");

const listaFilmes = document.getElementById("listaFilmes");



formFilme.addEventListener("submit", function (event) {

    
    event.preventDefault();


    
    const filme = {

        titulo: tituloInput.value,

        sinopse: sinopseInput.value,

        ano: Number(anoInput.value)

    };


    
    filmes.push(filme);


    
    filmes.sort(function (a, b) {

        return b.ano - a.ano;

    });


    
    exibirFilmes();


    
    formFilme.reset();

});



function exibirFilmes() {


    listaFilmes.innerHTML = "";



    filmes.forEach(function (filme, indice) {


        const div = document.createElement("div");


        div.className =
            "grid grid-cols-4 gap-2 border-b border-gray-300 p-3 items-center";


        
        div.innerHTML = `

            <div>
                ${filme.titulo}
            </div>

            <div>
                ${filme.sinopse}
            </div>

            <div>
                ${filme.ano}
            </div>

            <div>

                <button
                    onclick="excluirFilme(${indice})"
                    class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
                >

                    Excluir

                </button>

            </div>

        `;


    
        listaFilmes.appendChild(div);

    });

}



function excluirFilme(indice) {

    
    filmes.splice(indice, 1);


    
    exibirFilmes();

}